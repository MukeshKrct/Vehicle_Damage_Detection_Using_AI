-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 19, 2026 at 09:05 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `26cardamgeinsurancedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `regtb`
--

CREATE TABLE `regtb` (
  `id` bigint(20) NOT NULL auto_increment,
  `Name` varchar(250) NOT NULL,
  `Mobile` varchar(250) NOT NULL,
  `Email` varchar(250) NOT NULL,
  `Address` varchar(500) NOT NULL,
  `UserName` varchar(250) NOT NULL,
  `Password` varchar(250) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `regtb`
--

INSERT INTO `regtb` (`id`, `Name`, `Mobile`, `Email`, `Address`, `UserName`, `Password`) VALUES
(1, 'mukesh', 'mukesh', 'sangeeth5535@gmail.com', 'No 16, Samnath Plaza, Madurai Main Road, Melapudhur', 'mukesh', 'mukesh'),
(2, 'mukesh123', '9486365535', 'mukesh9696fc@gmail.com', 'No 16, Samnath Plaza, Madurai Main Road, Melapudhur', 'mukesh123', 'mukesh123');

-- --------------------------------------------------------

--
-- Table structure for table `reporttb`
--

CREATE TABLE `reporttb` (
  `id` bigint(10) NOT NULL auto_increment,
  `UserName` varchar(250) NOT NULL,
  `car_number` varchar(500) NOT NULL,
  `car_model` varchar(500) NOT NULL,
  `accident_date` varchar(500) NOT NULL,
  `accident_location` varchar(500) NOT NULL,
  `policy_number` varchar(500) NOT NULL,
  `Date` varchar(500) NOT NULL,
  `Time` varchar(500) NOT NULL,
  `image` varchar(500) NOT NULL,
  `detected_damage` varchar(500) NOT NULL,
  `total_cost` varchar(250) NOT NULL,
  `Status` varchar(250) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `reporttb`
--

INSERT INTO `reporttb` (`id`, `UserName`, `car_number`, `car_model`, `accident_date`, `accident_location`, `policy_number`, `Date`, `Time`, `image`, `detected_damage`, `total_cost`, `Status`) VALUES
(5, 'mukesh', 'TN23AL5534', 'i20', '2026-03-19', 'Trichy', '122353534', '2026-03-19', '13:57:56', 'static/result/3645.jpg', 'windshield_damage', '12000', 'Rejected'),
(6, 'mukesh123', 'TN23AL5538', 'SWIFT', '2026-03-19', 'Trichy', '23536457568', '2026-03-19', '14:32:40', 'static/result/7728.jpg', 'severe_scratch,severe_scratch', '16000', 'Approved');
