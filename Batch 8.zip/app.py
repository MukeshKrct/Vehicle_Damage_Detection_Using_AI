from flask import Flask, render_template, flash, request, session
import mysql.connector

app = Flask(__name__)
app.config['DEBUG']
app.config['SECRET_KEY'] = 'abc'


@app.route("/")
def home():
    return render_template('index.html')


@app.route("/AdminLogin")
def AdminLogin():
    return render_template('AdminLogin.html')


@app.route("/NewUser")
def NewUser():
    return render_template('Newuser.html')


@app.route("/Newuser", methods=['GET', 'POST'])
def Newuser():
    if request.method == 'POST':
        Name = request.form['name']
        Age = request.form['age']
        Gender = request.form['gender']
        Mobile = request.form['mobile']

        Email = request.form['email']

        Address = request.form['address']

        Username = request.form['username']
        Password = request.form['password']

        conn = mysql.connector.connect(user='root', password='', host='localhost', database='26cardamgeinsurancedb')
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO regtb VALUES ('','" + Name + "','" + Gender + "','" + Age + "' , '" + Email + "','" + Mobile + "','" + Address + "','" + Username + "','" + Password + "')")
        conn.commit()
        conn.close()
        flash(' USER REGISTER SUCCESSFULLY')

    return render_template('Userlogin.html')


@app.route("/adminlogin", methods=['GET', 'POST'])
def adminlogin():
    if request.method == 'POST':
        if request.form['username'] == 'admin' and request.form['password'] == 'admin':

            flash("LOGIN SUCCESSFULLY")

            conn = mysql.connector.connect(user='root', password='', host='localhost', database='26cardamgeinsurancedb')
            cur = conn.cursor()
            cur.execute("SELECT * FROM regtb ")
            data1 = cur.fetchall()
            return render_template('AdminHome.html', data=data1)

        else:
            flash("UserName Or Password Incorrect!")
            return render_template('AdminLogin.html')


@app.route("/UserLogin")
def UserLogin():
    return render_template('UserLogin.html')


@app.route("/AdminHome")
def AdminHome():
    conn = mysql.connector.connect(user='root', password='', host='localhost', database='26cardamgeinsurancedb')
    cur = conn.cursor()
    cur.execute("SELECT * FROM  regtb ")
    data1 = cur.fetchall()

    return render_template('Adminhome.html', data=data1)



@app.route("/Report")
def Report():
    conn = mysql.connector.connect(user='root', password='', host='localhost', database='26cardamgeinsurancedb')
    cur = conn.cursor()
    cur.execute("SELECT * FROM  reporttb ")
    data1 = cur.fetchall()
    return render_template('AReport.html', data=data1)


from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Image,
    Table, TableStyle, HRFlowable
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT

# ── Brand colours ───────────────────────────────────────────────────────────
NAVY = colors.HexColor("#0D1B2A")
TEAL = colors.HexColor("#1B9AAA")
TEAL_LITE = colors.HexColor("#E8F7F9")
GOLD = colors.HexColor("#F4A261")
LIGHT_BG = colors.HexColor("#F7F9FB")
MID_GREY = colors.HexColor("#8A9BB0")
DARK_GREY = colors.HexColor("#2E3A4E")
WHITE = colors.white


def _build_styles():
    base = getSampleStyleSheet()

    styles = {
        "report_title": ParagraphStyle(
            "report_title",
            fontName="Helvetica-Bold",
            fontSize=22,
            textColor=WHITE,
            alignment=TA_CENTER,
            spaceAfter=2,
        ),
        "report_subtitle": ParagraphStyle(
            "report_subtitle",
            fontName="Helvetica",
            fontSize=10,
            textColor=colors.HexColor("#B0C8D8"),
            alignment=TA_CENTER,
            spaceAfter=0,
        ),
        "section_heading": ParagraphStyle(
            "section_heading",
            fontName="Helvetica-Bold",
            fontSize=9,
            textColor=TEAL,
            spaceAfter=6,
            spaceBefore=4,
            letterSpacing=1.2,
        ),
        "label": ParagraphStyle(
            "label",
            fontName="Helvetica-Bold",
            fontSize=8,
            textColor=MID_GREY,
            spaceAfter=1,
        ),
        "value": ParagraphStyle(
            "value",
            fontName="Helvetica",
            fontSize=10,
            textColor=DARK_GREY,
            spaceAfter=0,
        ),
        "status_approved": ParagraphStyle(
            "status_approved",
            fontName="Helvetica-Bold",
            fontSize=11,
            textColor=colors.HexColor("#27AE60"),
            alignment=TA_CENTER,
        ),
        "status_pending": ParagraphStyle(
            "status_pending",
            fontName="Helvetica-Bold",
            fontSize=11,
            textColor=GOLD,
            alignment=TA_CENTER,
        ),
        "status_rejected": ParagraphStyle(
            "status_rejected",
            fontName="Helvetica-Bold",
            fontSize=11,
            textColor=colors.HexColor("#E74C3C"),
            alignment=TA_CENTER,
        ),
        "cost_label": ParagraphStyle(
            "cost_label",
            fontName="Helvetica",
            fontSize=9,
            textColor=WHITE,
            alignment=TA_CENTER,
        ),
        "cost_value": ParagraphStyle(
            "cost_value",
            fontName="Helvetica-Bold",
            fontSize=20,
            textColor=WHITE,
            alignment=TA_CENTER,
        ),
        "footer": ParagraphStyle(
            "footer",
            fontName="Helvetica",
            fontSize=7,
            textColor=MID_GREY,
            alignment=TA_CENTER,
        ),
        "image_caption": ParagraphStyle(
            "image_caption",
            fontName="Helvetica",
            fontSize=8,
            textColor=MID_GREY,
            alignment=TA_CENTER,
            spaceBefore=4,
        ),
    }
    return styles


def _header_table(data, styles):
    """Dark navy header banner with title + policy badge."""
    title_cell = [
        Paragraph("INSURANCE CLAIM REPORT", styles["report_title"]),
        Paragraph("AutoShield Insurance Services", styles["report_subtitle"]),
    ]
    policy_cell = [
        Paragraph("POLICY NO.", ParagraphStyle(
            "p", fontName="Helvetica", fontSize=7,
            textColor=colors.HexColor("#B0C8D8"), alignment=TA_RIGHT)),
        Paragraph(data.get("policy", "—"), ParagraphStyle(
            "p2", fontName="Helvetica-Bold", fontSize=11,
            textColor=GOLD, alignment=TA_RIGHT)),
    ]

    tbl = Table([[title_cell, policy_cell]], colWidths=["70%", "30%"])
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), NAVY),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (0, 0), 16),
        ("RIGHTPADDING", (1, 0), (1, 0), 16),
        ("TOPPADDING", (0, 0), (-1, -1), 16),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 16),
        ("ROUNDEDCORNERS", [6, 6, 6, 6]),
    ]))
    return tbl


def _info_row(label, value, styles):
    """One label+value pair as a mini 2-row table (looks like a card field)."""
    return Table(
        [[Paragraph(label.upper(), styles["label"])],
         [Paragraph(str(value), styles["value"])]],
        colWidths=["100%"],
    )


def _details_grid(data, styles):
    """Two-column card grid for claimant & vehicle info."""

    def cell(label, value):
        return _info_row(label, value, styles)

    grid_data = [
        [cell("Claimant Name", data.get("username", "—")),
         cell("Accident Date", data.get("accident_date", "—"))],
        [cell("Vehicle Number", data.get("car_number", "—")),
         cell("Vehicle Model", data.get("car_model", "—"))],
        [cell("Incident Location", data.get("location", "—")),
         cell("Detected Damage", data.get("damage", "—"))],
    ]

    tbl = Table(grid_data, colWidths=["50%", "50%"])
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), LIGHT_BG),
        ("ROWBACKGROUNDS", (0, 0), (-1, -1), [WHITE, LIGHT_BG]),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 12),
        ("RIGHTPADDING", (0, 0), (-1, -1), 12),
        ("TOPPADDING", (0, 0), (-1, -1), 10),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
        ("LINEBELOW", (0, 0), (-1, -2), 0.5, colors.HexColor("#DDE5EE")),
        ("LINEBEFORE", (1, 0), (1, -1), 0.5, colors.HexColor("#DDE5EE")),
        ("ROUNDEDCORNERS", [6, 6, 6, 6]),
        ("BOX", (0, 0), (-1, -1), 1, colors.HexColor("#DDE5EE")),
    ]))
    return tbl


def _cost_banner(cost, styles):
    """Teal cost highlight bar."""
    tbl = Table(
        [[Paragraph("TOTAL ESTIMATED COST", styles["cost_label"]),
          Paragraph(f"\u20b9{cost}", styles["cost_value"])]],
        colWidths=["45%", "55%"],
    )
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), TEAL),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 16),
        ("RIGHTPADDING", (0, 0), (-1, -1), 16),
        ("TOPPADDING", (0, 0), (-1, -1), 14),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 14),
        ("ROUNDEDCORNERS", [6, 6, 6, 6]),
    ]))
    return tbl


def _status_badge(status, styles):
    """Coloured status pill."""
    status_upper = status.upper()
    if "APPROVE" in status_upper:
        style_key, bg = "status_approved", colors.HexColor("#EAFAF1")
        border = colors.HexColor("#27AE60")
    elif "REJECT" in status_upper:
        style_key, bg = "status_rejected", colors.HexColor("#FDEDEC")
        border = colors.HexColor("#E74C3C")
    else:
        style_key, bg = "status_pending", colors.HexColor("#FEF9E7")
        border = GOLD

    tbl = Table([[Paragraph(f"STATUS: {status}", styles[style_key])]],
                colWidths=["100%"])
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), bg),
        ("BOX", (0, 0), (-1, -1), 1.5, border),
        ("TOPPADDING", (0, 0), (-1, -1), 10),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
        ("ROUNDEDCORNERS", [6, 6, 6, 6]),
    ]))
    return tbl


def _section_label(text, styles):
    return Paragraph(text.upper(), styles["section_heading"])


def generate_pdf(data, filepath):
    doc = SimpleDocTemplate(
        filepath,
        pagesize=A4,
        leftMargin=20 * mm,
        rightMargin=20 * mm,
        topMargin=18 * mm,
        bottomMargin=18 * mm,
        title="Insurance Claim Report",
        author="AutoShield Insurance Services",
    )

    styles = _build_styles()
    story = []

    # ── Header ───────────────────────────────────────────────────────────────
    story.append(_header_table(data, styles))
    story.append(Spacer(1, 14))

    # ── Claimant & Vehicle Details ────────────────────────────────────────────
    story.append(_section_label("Claim Details", styles))
    story.append(_details_grid(data, styles))
    story.append(Spacer(1, 14))

    # ── Cost banner ───────────────────────────────────────────────────────────
    story.append(_cost_banner(data.get("cost", "0"), styles))
    story.append(Spacer(1, 10))

    # ── Status badge ──────────────────────────────────────────────────────────
    story.append(_status_badge(data.get("status", "Pending"), styles))
    story.append(Spacer(1, 18))

    # ── Damage Photo ──────────────────────────────────────────────────────────
    story.append(HRFlowable(width="100%", thickness=1,
                            color=colors.HexColor("#DDE5EE"), spaceAfter=10))
    story.append(_section_label("Vehicle Damage Photo", styles))

    img_path = data.get("image")
    if img_path:
        img = Image(img_path, width=160 * mm, height=90 * mm)
        img.hAlign = "CENTER"
        # Wrap image in a bordered table for a frame effect
        img_tbl = Table([[img]], colWidths=["100%"])
        img_tbl.setStyle(TableStyle([
            ("BOX", (0, 0), (-1, -1), 1, colors.HexColor("#DDE5EE")),
            ("BACKGROUND", (0, 0), (-1, -1), LIGHT_BG),
            ("TOPPADDING", (0, 0), (-1, -1), 8),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
            ("ROUNDEDCORNERS", [4, 4, 4, 4]),
        ]))
        story.append(img_tbl)
        story.append(Paragraph("Photo submitted by claimant at time of incident",
                               styles["image_caption"]))

    story.append(Spacer(1, 20))

    # ── Footer ────────────────────────────────────────────────────────────────
    story.append(HRFlowable(width="100%", thickness=0.5,
                            color=colors.HexColor("#DDE5EE"), spaceAfter=6))
    story.append(Paragraph(
        "This document is auto-generated by AutoShield Claims System · "
        "For queries contact claims@autoshield.in · Confidential",
        styles["footer"],
    ))

    doc.build(story)
    print(f"✅ PDF saved → {filepath}")

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from email.mime.text import MIMEText

def send_email(toaddr, pdf_path):

    fromaddr = "projectmailm@gmail.com"

    msg = MIMEMultipart()
    msg['From'] = fromaddr
    msg['To'] = toaddr
    msg['Subject'] = "Insurance Claim Approved"

    body = "Your insurance claim has been approved. Please find the attached report."
    msg.attach(MIMEText(body, 'plain'))

    # 🔥 Attach PDF
    filename = pdf_path.split("/")[-1]
    attachment = open(pdf_path, "rb")

    p = MIMEBase('application', 'octet-stream')
    p.set_payload(attachment.read())
    encoders.encode_base64(p)

    p.add_header('Content-Disposition', f"attachment; filename={filename}")
    msg.attach(p)

    # 🔥 SMTP
    s = smtplib.SMTP('smtp.gmail.com', 587)
    s.starttls()
    s.login(fromaddr, "tdyr kebi hnyr yzyh")

    s.sendmail(fromaddr, toaddr, msg.as_string())
    s.quit()


@app.route('/approve/<int:id>')
def approve(id):
    conn = mysql.connector.connect(user='root', password='', host='localhost', database='26cardamgeinsurancedb')
    cursor = conn.cursor(dictionary=True)

    # ✅ Update status
    cursor.execute("UPDATE reporttb SET Status='Approved' WHERE id=%s", (id,))
    conn.commit()

    # ✅ Get report data
    cursor.execute("SELECT * FROM reporttb WHERE id=%s", (id,))
    report = cursor.fetchone()

    # ✅ Get user email from regtb
    cursor.execute("SELECT Email FROM regtb WHERE UserName=%s", (report['UserName'],))
    user = cursor.fetchone()

    conn.close()

    # 🔥 Prepare data
    pdf_data = {
        'username': report['UserName'],
        'car_number': report['car_number'],
        'car_model': report['car_model'],
        'accident_date': report['accident_date'],
        'location': report['accident_location'],
        'policy': report['policy_number'],
        'damage': report['detected_damage'],
        'cost': report['total_cost'],
        'status': report['Status'],
        'image': report['image']
    }

    pdf_path = f"static/report_{id}.pdf"

    generate_pdf(pdf_data, pdf_path)

    # 🔥 Send Mail
    send_email(user['Email'], pdf_path)

    return Report()


@app.route('/reject/<int:id>')
def reject(id):
    conn = mysql.connector.connect(user='root', password='', host='localhost', database='26cardamgeinsurancedb')
    cursor = conn.cursor(dictionary=True)

    # ✅ Update status
    cursor.execute("UPDATE reporttb SET Status='Rejected' WHERE id=%s", (id,))
    conn.commit()

    # ✅ Get report data
    cursor.execute("SELECT * FROM reporttb WHERE id=%s", (id,))
    report = cursor.fetchone()

    # ✅ Get user email from regtb
    cursor.execute("SELECT Email FROM regtb WHERE UserName=%s", (report['UserName'],))
    user = cursor.fetchone()

    conn.close()

    sendmail11(user['Email'],"Your Insurance Request Rejected..!")

    return Report()


def sendmail11(Mailid,message):
    import smtplib
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    from email.mime.base import MIMEBase
    from email import encoders

    fromaddr = "projectmailm@gmail.com"
    toaddr = Mailid

    # instance of MIMEMultipart
    msg = MIMEMultipart()

    # storing the senders email address
    msg['From'] = fromaddr

    # storing the receivers email address
    msg['To'] = toaddr

    # storing the subject
    msg['Subject'] = "Alert"

    # string to store the body of the mail
    body = message

    # attach the body with the msg instance
    msg.attach(MIMEText(body, 'plain'))

    # creates SMTP session
    s = smtplib.SMTP('smtp.gmail.com', 587)

    # start TLS for security
    s.starttls()

    # Authentication
    s.login(fromaddr, "tdyr kebi hnyr yzyh")

    # Converts the Multipart msg into a string
    text = msg.as_string()

    # sending the mail
    s.sendmail(fromaddr, toaddr, text)

    # terminating the session
    s.quit()

@app.route("/newuser", methods=['GET', 'POST'])
def newuser():
    if request.method == 'POST':
        name = request.form['uname']
        mobile = request.form['mobile']
        email = request.form['email']
        address = request.form['address']
        username = request.form['username']
        password = request.form['password']

        conn = mysql.connector.connect(user='root', password='', host='localhost', database='26cardamgeinsurancedb')
        cursor = conn.cursor()
        cursor.execute(
            "insert into regtb values('','" + name + "','" + mobile + "','" + email + "','" + address + "','" + username + "','" + password + "')")
        conn.commit()
        conn.close()
        flash("Record Saved!")
    return render_template('UserLogin.html')


@app.route("/userlogin", methods=['GET', 'POST'])
def userlogin():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        session['uname'] = request.form['username']

        conn = mysql.connector.connect(user='root', password='', host='localhost', database='26cardamgeinsurancedb')
        cursor = conn.cursor()
        cursor.execute("SELECT * from regtb where username='" + username + "' and password='" + password + "'")
        data = cursor.fetchone()
        if data is None:

            flash('Username or Password is wrong')
            return render_template('Userlogin.html')
        else:

            session['mob'] = data[2]
            session['email'] = data[3]

            conn = mysql.connector.connect(user='root', password='', host='localhost', database='26cardamgeinsurancedb')
            cur = conn.cursor()
            cur.execute("SELECT * FROM regtb where username='" + username + "' and Password='" + password + "'")
            data1 = cur.fetchall()
            flash("LOGIN SUCCESSFULLY")

            return render_template('Userhome.html', data=data1)


@app.route("/ImPredict")
def ImPredict():
    return render_template('ImPredict.html')




@app.route("/userlogin1", methods=['GET', 'POST'])
def userlogin1():
    if request.method == 'POST':
        conn = mysql.connector.connect(user='root', password='', host='localhost', database='26cardamgeinsurancedb')
        cur = conn.cursor()
        cur.execute("SELECT * FROM regtb where username='" + session['uname'] + "' ")
        data1 = cur.fetchall()
        return render_template('Userhome.html', data=data1)

@app.route("/Userhome")
def Userhome():
    conn = mysql.connector.connect(user='root', password='', host='localhost', database='26cardamgeinsurancedb')
    cur = conn.cursor()
    cur.execute("SELECT * FROM regtb where username='" + session['uname'] + "' ")
    data1 = cur.fetchall()
    return render_template('Userhome.html', data=data1)

@app.route("/UReport")
def UReport():
    conn = mysql.connector.connect(user='root', password='', host='localhost', database='26cardamgeinsurancedb')
    cur = conn.cursor()
    cur.execute("SELECT * FROM reporttb where username='" + session['uname'] + "' ")
    data1 = cur.fetchall()
    return render_template('UReport.html', data=data1)


DAMAGE_COST = {
    'crack_and_hole': 6000,
    'medium_deformation': 10000,
    'severe_deformation': 50000,
    'severe_scratch': 8000,
    'slight_deformation': 5000,
    'slight_scratch': 3000,
    'windshield_damage': 12000
}

from ultralytics import YOLO

model = YOLO('runs/detect/Newcardamge/weights/best.pt')  # your trained model

def predict_damage(image_path):
    results = model(image_path)

    detected_classes = []
    annotated_image = None

    for r in results:
        annotated_image = r.plot()  # 🔥 bounding box image
        for box in r.boxes:
            cls_id = int(box.cls[0])
            class_name = model.names[cls_id]
            detected_classes.append(class_name)

    return detected_classes, annotated_image



def calculate_total_cost(detected_classes):
    total_cost = 0
    details = []

    for cls in detected_classes:
        cost = DAMAGE_COST.get(cls, 0)
        total_cost += cost
        details.append((cls, cost))

    return total_cost, details


@app.route("/impredict", methods=['GET', 'POST'])
def impredict():
    if request.method == 'POST':
        import os
        import cv2
        import datetime
        import random

        car_number = request.form['car_number']
        car_model = request.form['car_model']
        accident_date = request.form['accident_date']
        accident_location = request.form['accident_location']
        policy_number = request.form['policy_number']

        file = request.files['file']

        loginkey = random.randint(1111, 9999)

        upload_path = f"static/upload/{loginkey}.jpg"
        result_path = f"static/result/{loginkey}.jpg"

        file.save(upload_path)

        # 🔥 YOLO Prediction
        detected, annotated_image = predict_damage(upload_path)

        # ❌ STOP if no prediction
        if not detected or annotated_image is None:
            return render_template("Result.html",
                                   org=upload_path,
                                   out=0,
                                   pre=[],
                                   msg="⚠️ No damage detected. Please upload a clear image.")

        # 🔥 Cost
        total_cost, breakdown = calculate_total_cost(detected)

        # 🔥 Save image
        cv2.imwrite(result_path, annotated_image)

        detected_str = ",".join(detected)

        now = datetime.datetime.now()
        date = now.strftime('%Y-%m-%d')
        time = now.strftime('%H:%M:%S')

        # 🔥 DB save ONLY if valid
        conn = mysql.connector.connect(
            user='root',
            password='',
            host='localhost',
            database='26cardamgeinsurancedb'
        )
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO reporttb 
            (UserName,car_number, car_model, accident_date, accident_location, policy_number,
             date, time, image, detected_damage, total_cost,Status)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
        """, (
            session['uname'],
            car_number,
            car_model,
            accident_date,
            accident_location,
            policy_number,
            date,
            time,
            result_path,
            detected_str,
            total_cost,
            "Pending"
        ))

        conn.commit()
        conn.close()

        return render_template('Result.html',
                               org=result_path,
                               out=total_cost,
                               pre=breakdown)



def sendmsg(targetno,message):
    import requests
    requests.post(
        "http://sms.creativepoint.in/api/push.json?apikey=6555c521622c1&route=transsms&sender=FSSMSS&mobileno=" + targetno + "&text=Dear customer your msg is " + message + "  Sent By FSMSG FSSMSS")


def sendmail():
    import smtplib
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    from email.mime.base import MIMEBase
    from email import encoders

    fromaddr = "projectmailm@gmail.com"
    toaddr =  session['email']

    # instance of MIMEMultipart
    msg = MIMEMultipart()

    # storing the senders email address
    msg['From'] = fromaddr

    # storing the receivers email address
    msg['To'] = toaddr

    # storing the subject
    msg['Subject'] = "Alert"

    # string to store the body of the mail
    body = "Crack Detection"

    # attach the body with the msg instance
    msg.attach(MIMEText(body, 'plain'))

    # open the file to be sent
    filename = "alert.jpg"
    attachment = open("alert.jpg", "rb")

    # instance of MIMEBase and named as p
    p = MIMEBase('application', 'octet-stream')

    # To change the payload into encoded form
    p.set_payload((attachment).read())

    # encode into base64
    encoders.encode_base64(p)

    p.add_header('Content-Disposition', "attachment; filename= %s" % filename)

    # attach the instance 'p' to instance 'msg'
    msg.attach(p)

    # creates SMTP session
    s = smtplib.SMTP('smtp.gmail.com', 587)

    # start TLS for security
    s.starttls()

    # Authentication
    s.login(fromaddr, "qmgn xecl bkqv musr")

    # Converts the Multipart msg into a string
    text = msg.as_string()

    # sending the mail
    s.sendmail(fromaddr, toaddr, text)

    # terminating the session
    s.quit()





if __name__ == '__main__':
    app.run(debug=True, use_reloader=True)
